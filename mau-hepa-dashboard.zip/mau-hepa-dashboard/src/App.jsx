
import React, { useMemo, useState } from "react";
import * as XLSX from "xlsx";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, BarChart, Bar, ReferenceLine
} from "recharts";
import {
  Upload, Save, RefreshCcw, Bell, Archive, Trash2,
  Settings, CheckCircle2, SlidersHorizontal
} from "lucide-react";

const MACHINES = ["MAUC01","MAUC02","MAUC03","MAUC04","MAUC05","MAUC06","MAUC07","MAUC08"];

const DEFAULT_HEPA_SETTINGS = {
  MAUC01: { replaceDate: "2024-07-18", initialPT: 77 },
  MAUC02: { replaceDate: "2024-09-25", initialPT: 53 },
  MAUC03: { replaceDate: "2023-07-03", initialPT: 180 },
  MAUC04: { replaceDate: "2024-05-24", initialPT: 75 },
  MAUC05: { replaceDate: "2024-05-03", initialPT: 77 },
  MAUC06: { replaceDate: "2024-09-25", initialPT: 67 },
  MAUC07: { replaceDate: "2024-05-03", initialPT: 79 },
  MAUC08: { replaceDate: "2024-07-18", initialPT: 64 },
};

const DEFAULT_ENERGY_CONFIG = {
  designCMH: 120000,
  fanEfficiency: 0.8,
  hepaUnitCost: 3900,
  hepaQty: 42,
  laborCost: 18000,
  electricityPrice: 3.95,
  earlyWarningDays: 90,
  minUseDays: 30,
  smoothWindow: 7,
};

const COLORS = {
  hepa: "#2563eb",
  kwh: "#16a34a",
  cost: "#9333ea",
  annual: "#ea580c",
  annualHepa: "#0f766e",
  annualExtra: "#7c3aed",
  mc: "#dc2626",
  ac: "#2563eb",
};

function lsGet(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function lsSet(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

function num(v) {
  if (v === null || v === undefined || v === "") return NaN;
  if (typeof v === "number") return v;
  const n = Number(String(v).replace(/,/g, "").trim());
  return Number.isFinite(n) ? n : NaN;
}

function parseDate(v) {
  if (!v) return null;
  if (v instanceof Date && !Number.isNaN(v.getTime())) return v;
  if (typeof v === "number") {
    const p = XLSX.SSF.parse_date_code(v);
    if (p) return new Date(p.y, p.m - 1, p.d, p.H || 0, p.M || 0, p.S || 0);
  }
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

function dateKey(d) {
  const x = parseDate(d);
  if (!x) return "";
  return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,"0")}-${String(x.getDate()).padStart(2,"0")}`;
}

function addDays(d, days) {
  const x = parseDate(d);
  if (!x) return null;
  const out = new Date(x);
  out.setDate(out.getDate() + days);
  return out;
}

function movingAverage(rows, key, windowSize) {
  return rows.map((row, i) => {
    const s = Math.max(0, i - windowSize + 1);
    const vals = rows.slice(s, i + 1).map(r => r[key]).filter(Number.isFinite);
    return { ...row, [`${key}_smooth`]: vals.length ? vals.reduce((a,b)=>a+b,0) / vals.length : null };
  });
}

function normalizeRows(rawRows) {
  const rows = rawRows.map((r, idx) => {
    const ts = parseDate(r.TimeStamp || r.timestamp || r["日期時間"]);
    return { ...r, __idx: idx, __TimeStamp: ts, __Date: ts ? dateKey(ts) : null };
  }).filter(r => r.__TimeStamp).sort((a,b) => a.__TimeStamp - b.__TimeStamp);

  return rows.map((r, i) => {
    let deltaHours = 1;
    if (i === 0 && rows.length > 1) deltaHours = (rows[1].__TimeStamp - r.__TimeStamp) / 36e5;
    if (i > 0) deltaHours = (r.__TimeStamp - rows[i-1].__TimeStamp) / 36e5;
    if (!Number.isFinite(deltaHours) || deltaHours <= 0 || deltaHours > 24) deltaHours = 1;
    return { ...r, __DeltaHours: deltaHours };
  });
}

function aggregateDaily(rawRows, hepaSettings, config) {
  const rows = normalizeRows(rawRows);
  const dataStart = rows.length ? rows[0].__TimeStamp : null;
  const dataEnd = rows.length ? rows[rows.length - 1].__TimeStamp : null;
  const replacementCost = config.hepaUnitCost * config.hepaQty + config.laborCost;
  const maps = Object.fromEntries(MACHINES.map(m => [m, new Map()]));

  for (const row of rows) {
    for (const m of MACHINES) {
      const setting = hepaSettings[m];
      const kw = num(row[`${m}_KW`]);
      const freq = num(row[`${m}_FREQ`]);
      const hepa = num(row[`${m}_HEPAPT`]);
      const cold = num(row[`${m}_ColdPT`]);
      const filter = num(row[`${m}_FilterPT`]);
      if (!setting || !Number.isFinite(hepa)) continue;

      const replaceDate = parseDate(setting.replaceDate);
      const initialPT = num(setting.initialPT);
      const afterReplace = replaceDate ? row.__TimeStamp >= replaceDate : false;
      const running = Number.isFinite(kw) && Number.isFinite(freq) && kw > 0 && freq > 0;
      const q = config.designCMH * freq / 60 / 3600;
      const extraDeltaP = Math.max(hepa - initialPT, 0);

      let extraKWh = null;
      if (afterReplace && running && Number.isFinite(q)) {
        extraKWh = q * extraDeltaP * row.__DeltaHours / (config.fanEfficiency * 1000);
      } else if (afterReplace && !running) {
        extraKWh = 0;
      }

      const key = row.__Date;
      if (!maps[m].has(key)) {
        maps[m].set(key, {
          date: key, machine: m, records: 0, runRecords: 0,
          hepaSum: 0, hepaCount: 0, freqSum: 0, freqCount: 0,
          kwSum: 0, kwCount: 0, coldSum: 0, coldCount: 0,
          filterSum: 0, filterCount: 0, extraKWh: 0, extraCost: 0
        });
      }
      const d = maps[m].get(key);
      d.records += 1;
      if (running) d.runRecords += 1;
      d.hepaSum += hepa; d.hepaCount += 1;
      if (Number.isFinite(freq)) { d.freqSum += freq; d.freqCount += 1; }
      if (Number.isFinite(kw)) { d.kwSum += kw; d.kwCount += 1; }
      if (Number.isFinite(cold)) { d.coldSum += cold; d.coldCount += 1; }
      if (Number.isFinite(filter)) { d.filterSum += filter; d.filterCount += 1; }
      if (extraKWh !== null) {
        d.extraKWh += extraKWh;
        d.extraCost += extraKWh * config.electricityPrice;
      }
    }
  }

  const out = {};
  for (const m of MACHINES) {
    const setting = hepaSettings[m];
    const replaceDate = parseDate(setting.replaceDate);
    const initialPT = num(setting.initialPT);
    const hasLifecycleStart = !!(dataStart && dataEnd && replaceDate && dataStart <= replaceDate && replaceDate <= dataEnd);

    let cumulativeExtraCost = 0;
    let cumulativeExtraKWh = 0;
    let observedCost = 0;
    let observedKWh = 0;

    let daily = Array.from(maps[m].values()).sort((a,b) => a.date.localeCompare(b.date)).map(d => {
      const currentDate = parseDate(d.date);
      const useDays = replaceDate ? Math.floor((currentDate - replaceDate) / 86400000) + 1 : null;
      const afterReplace = replaceDate && currentDate >= replaceDate;
      const hepaMean = d.hepaCount ? d.hepaSum / d.hepaCount : null;
      const freqMean = d.freqCount ? d.freqSum / d.freqCount : null;
      const kwMean = d.kwCount ? d.kwSum / d.kwCount : null;
      const runRate = d.records ? d.runRecords / d.records : null;

      observedCost += d.extraCost || 0;
      observedKWh += d.extraKWh || 0;

      if (hasLifecycleStart && afterReplace) {
        cumulativeExtraCost += d.extraCost || 0;
        cumulativeExtraKWh += d.extraKWh || 0;
      }

      const annualHepaCost = hasLifecycleStart && afterReplace && useDays > 0 ? replacementCost / useDays * 365 : null;
      const annualExtraCost = hasLifecycleStart && afterReplace && useDays > 0 ? cumulativeExtraCost / useDays * 365 : null;
      const annualTotalCost = Number.isFinite(annualHepaCost) && Number.isFinite(annualExtraCost) ? annualHepaCost + annualExtraCost : null;
      const totalCost = hasLifecycleStart && afterReplace ? replacementCost + cumulativeExtraCost : null;
      const acDay = hasLifecycleStart && afterReplace && useDays > 0 ? totalCost / useDays : null;

      return {
        ...d, hepaMean, freqMean, kwMean, runRate, initialPT,
        replaceDate: setting.replaceDate, useDays, hasLifecycleStart,
        hepaExtraPT: hepaMean === null ? null : Math.max(hepaMean - initialPT, 0),
        observedCumulativeCost: observedCost,
        observedCumulativeKWh: observedKWh,
        lifecycleCumulativeCost: hasLifecycleStart && afterReplace ? cumulativeExtraCost : null,
        lifecycleCumulativeKWh: hasLifecycleStart && afterReplace ? cumulativeExtraKWh : null,
        annualHepaCost, annualExtraCost, annualTotalCost,
        mcDay: d.extraCost,
        acDay,
        mcMinusAcDay: Number.isFinite(acDay) ? d.extraCost - acDay : null,
      };
    });

    daily = movingAverage(daily, "annualTotalCost", config.smoothWindow);
    daily = movingAverage(daily, "mcDay", config.smoothWindow);
    daily = movingAverage(daily, "acDay", config.smoothWindow);

    daily = daily.map((row, i) => {
      const prev = daily[i - 1];
      const mcMinusAcDay_smooth =
        Number.isFinite(row.mcDay_smooth) && Number.isFinite(row.acDay_smooth)
          ? row.mcDay_smooth - row.acDay_smooth
          : null;
      if (!prev || !Number.isFinite(row.annualTotalCost_smooth) || !Number.isFinite(prev.annualTotalCost_smooth)) {
        return { ...row, annualSlope: null, mcMinusAcDay_smooth };
      }
      const dayDiff = Math.max(1, row.useDays - prev.useDays);
      return {
        ...row,
        annualSlope: (row.annualTotalCost_smooth - prev.annualTotalCost_smooth) / dayDiff,
        mcMinusAcDay_smooth,
      };
    });

    daily = movingAverage(daily, "annualSlope", config.smoothWindow);

    const annualCandidates = daily.filter(d => d.hasLifecycleStart && d.useDays >= config.minUseDays && Number.isFinite(d.annualSlope_smooth));
    const slopeCross = annualCandidates.find((d, i) => i > 0 && annualCandidates[i-1].annualSlope_smooth < 0 && d.annualSlope_smooth >= 0);

    let slopeOptimum = slopeCross || null;
    let slopeForecast = null;
    let slopeStatus = slopeCross ? "Slope_Crossed_Zero" : "NoCandidate";

    if (!slopeOptimum && annualCandidates.length >= 14) {
      const latestSlope = annualCandidates[annualCandidates.length - 1];
      if (latestSlope.annualSlope_smooth < 0) {
        const recent = annualCandidates.slice(-60);
        const first = recent[0];
        const last = recent[recent.length - 1];
        const slopeRate = (last.annualSlope_smooth - first.annualSlope_smooth) / Math.max(1, last.useDays - first.useDays);
        let daysToZero = Number.isFinite(slopeRate) && slopeRate > 0 ? Math.ceil(Math.abs(latestSlope.annualSlope_smooth) / slopeRate) : 365;
        if (!Number.isFinite(daysToZero) || daysToZero < 0 || daysToZero > 3650) daysToZero = 365;
        const predictedDate = addDays(latestSlope.date, daysToZero);
        slopeForecast = { ...latestSlope, date: dateKey(predictedDate), isForecast: true, daysToOptimum: daysToZero };
        slopeStatus = "Future_SlopeForecast";
      } else {
        slopeOptimum = annualCandidates.reduce((best, cur) => Math.abs(cur.annualSlope_smooth) < Math.abs(best.annualSlope_smooth) ? cur : best);
        slopeStatus = "Slope_Already_Positive";
      }
    }

    const mcCandidates = daily.filter(d => d.hasLifecycleStart && d.useDays >= config.minUseDays && Number.isFinite(d.mcMinusAcDay_smooth));
    const mcCross = mcCandidates.find((d, i) => i > 0 && mcCandidates[i-1].mcMinusAcDay_smooth < 0 && d.mcMinusAcDay_smooth >= 0);
    const mcAcOptimum = mcCross || (mcCandidates.length ? mcCandidates.reduce((best, cur) => Math.abs(cur.mcMinusAcDay_smooth) < Math.abs(best.mcMinusAcDay_smooth) ? cur : best) : null);

    const latest = daily[daily.length - 1] || null;
    let alert = { level: "NoData", message: "尚未匯入資料", daysToOptimum: null, optimumDate: null, yellowDate: null };

    if (latest && !hasLifecycleStart) {
      alert = { level: "ObservedOnly", message: "資料未包含清洗起始日，僅顯示觀測區間累積", daysToOptimum: null, optimumDate: null, yellowDate: null };
    } else if (latest && (slopeOptimum || slopeForecast)) {
      const base = slopeOptimum || slopeForecast;
      const daysToOptimum = Math.ceil((parseDate(base.date) - parseDate(latest.date)) / 86400000);
      const yellowDate = dateKey(addDays(base.date, -config.earlyWarningDays));
      if ((slopeStatus === "Slope_Crossed_Zero" || slopeStatus === "Slope_Already_Positive") && daysToOptimum < 0) {
        alert = { level: "Red", message: "必須清洗", daysToOptimum, optimumDate: base.date, yellowDate };
      } else if ((slopeStatus === "Slope_Crossed_Zero" || slopeStatus === "Slope_Already_Positive") && daysToOptimum === 0) {
        alert = { level: "Orange", message: "最佳更換點", daysToOptimum, optimumDate: base.date, yellowDate };
      } else if (daysToOptimum <= config.earlyWarningDays) {
        alert = { level: "Yellow", message: "即可清洗", daysToOptimum, optimumDate: base.date, yellowDate };
      } else {
        alert = { level: "Normal", message: "尚未進入清洗通知期", daysToOptimum, optimumDate: base.date, yellowDate };
      }
    } else if (latest) {
      alert = { level: "Unknown", message: "生命週期資料不足，尚無法判斷", daysToOptimum: null, optimumDate: null, yellowDate: null };
    }

    out[m] = {
      daily, hasLifecycleStart,
      dataStart: dataStart ? dateKey(dataStart) : null,
      dataEnd: dataEnd ? dateKey(dataEnd) : null,
      slopeOptimum, slopeForecast, slopeStatus, mcAcOptimum,
      alert, replacementCost,
    };
  }
  return out;
}

function StatPill({ label, value }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
      <div className="text-xs text-slate-500">{label}</div>
      <div className="mt-1 text-lg font-semibold text-slate-900">{value}</div>
    </div>
  );
}

function ChartCard({ title, children }) {
  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="mb-3">
        <h3 className="text-base font-semibold text-slate-900">{title}</h3>
      </div>
      <div className="h-[320px]">{children}</div>
    </div>
  );
}

function AlertBadge({ level, message }) {
  const style = {
    Normal: "bg-emerald-50 text-emerald-700 border-emerald-200",
    Yellow: "bg-yellow-50 text-yellow-700 border-yellow-300",
    Orange: "bg-orange-50 text-orange-700 border-orange-300",
    Red: "bg-red-50 text-red-700 border-red-300",
    ObservedOnly: "bg-slate-50 text-slate-700 border-slate-300",
    Unknown: "bg-slate-50 text-slate-700 border-slate-300",
    NoData: "bg-slate-50 text-slate-700 border-slate-300",
  }[level] || "bg-slate-50 text-slate-700 border-slate-300";
  return <span className={`inline-flex rounded-full border px-3 py-1 text-sm font-semibold ${style}`}>{message}</span>;
}

function fmt(value, digits = 0) {
  return Number.isFinite(value) ? value.toLocaleString(undefined, { maximumFractionDigits: digits }) : "-";
}

function defaultStartDate(machine, hepaSettings) {
  return hepaSettings[machine]?.replaceDate || "";
}

export default function App() {
  const [rawRows, setRawRows] = useState([]);
  const [fileName, setFileName] = useState("");
  const [selectedMachine, setSelectedMachine] = useState("MAUC01");
  const [hepaSettings, setHepaSettings] = useState(() => lsGet("mau_hepa_settings", DEFAULT_HEPA_SETTINGS));
  const [energyConfig, setEnergyConfig] = useState(() => lsGet("mau_energy_config", DEFAULT_ENERGY_CONFIG));
  const [editHepa, setEditHepa] = useState(hepaSettings);
  const [editConfig, setEditConfig] = useState(energyConfig);
  const [archives, setArchives] = useState(() => lsGet("mau_hepa_archives", []));
  const [hepaUndoStack, setHepaUndoStack] = useState(() => lsGet("mau_hepa_undo_stack", {}));
  const [dateRange, setDateRange] = useState({ start: "", end: "" });
  const [restoreConfirm, setRestoreConfirm] = useState(null);
  const [deleteArchiveConfirm, setDeleteArchiveConfirm] = useState(null);
  const [selectedArchiveId, setSelectedArchiveId] = useState(null);

  const dashboardData = useMemo(() => aggregateDaily(rawRows, hepaSettings, energyConfig), [rawRows, hepaSettings, energyConfig]);
  const selected = dashboardData[selectedMachine] || { daily: [], alert: { level: "NoData", message: "尚未匯入資料" } };
  const daily = selected.daily || [];
  const latest = daily[daily.length - 1];
  const replacementCost = energyConfig.hepaUnitCost * energyConfig.hepaQty + energyConfig.laborCost;
  const selectedArchives = archives.filter(a => a.machine === selectedMachine);
  const selectedArchive = selectedArchives.find(a => a.id === selectedArchiveId) || null;
  const selectedArchiveChartData = selectedArchive ? daily.filter(d => {
    const current = parseDate(d.date);
    const start = parseDate(selectedArchive.fromReplaceDate);
    const end = parseDate(selectedArchive.toReplaceDate);
    return (!start || current >= start) && (!end || current <= end);
  }) : [];

  const rangeStart = dateRange.start || defaultStartDate(selectedMachine, hepaSettings);
  const rangeEnd = dateRange.end || selected.dataEnd || "";
  const chartData = daily.filter(d => {
    const current = parseDate(d.date);
    const start = parseDate(rangeStart);
    const end = parseDate(rangeEnd);
    return (!start || current >= start) && (!end || current <= end);
  });

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: "array", cellDates: true });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const json = XLSX.utils.sheet_to_json(sheet, { defval: null });
    setRawRows(json);
    setFileName(file.name);
    setDateRange({ start: "", end: "" });
  }

  function saveSelectedHepa() {
    const oldSetting = { ...hepaSettings[selectedMachine] };
    const oldDate = hepaSettings[selectedMachine]?.replaceDate;
    const newDate = editHepa[selectedMachine]?.replaceDate;
    const nextSettings = { ...hepaSettings, [selectedMachine]: { ...editHepa[selectedMachine] } };
    const nextArchives = [...archives];
    const undoId = `${selectedMachine}-${Date.now()}`;
    const nextUndoStack = {
      ...hepaUndoStack,
      [selectedMachine]: { id: undoId, setting: oldSetting, archiveIds: [] },
    };

    if (oldDate && newDate && oldDate !== newDate && rawRows.length) {
      const newD = parseDate(newDate);
      if (newD) {
        const archivedRows = normalizeRows(rawRows).filter(r => r.__TimeStamp < newD);
        const archiveId = `${selectedMachine}-${oldDate}-to-${newDate}-${Date.now()}`;
        nextArchives.push({
          id: archiveId, undoId, machine: selectedMachine,
          fromReplaceDate: oldDate, toReplaceDate: newDate,
          rowCount: archivedRows.length, archivedAt: new Date().toISOString(),
        });
        nextUndoStack[selectedMachine].archiveIds.push(archiveId);
      }
    }

    setHepaSettings(nextSettings);
    setArchives(nextArchives);
    setHepaUndoStack(nextUndoStack);
    lsSet("mau_hepa_settings", nextSettings);
    lsSet("mau_hepa_archives", nextArchives);
    lsSet("mau_hepa_undo_stack", nextUndoStack);
    setDateRange({ start: "", end: "" });
  }

  function restoreSelectedHepa() {
    const record = hepaUndoStack[selectedMachine];
    const previous = record?.setting || record;
    if (!previous) {
      window.alert(`${selectedMachine.replace("MAUC", "C")} 尚無可還原的上一筆儲存紀錄`);
      return;
    }
    setRestoreConfirm({
      machine: selectedMachine,
      currentSetting: { ...hepaSettings[selectedMachine] },
      previousSetting: { ...previous },
      archiveIds: record?.archiveIds || [],
    });
  }

  function confirmRestoreSelectedHepa() {
    if (!restoreConfirm) return;
    const machine = restoreConfirm.machine;
    const previous = restoreConfirm.previousSetting;
    const archiveIdsToRemove = restoreConfirm.archiveIds || [];

    const nextSettings = { ...hepaSettings, [machine]: { ...previous } };
    const nextEditHepa = { ...editHepa, [machine]: { ...previous } };
    const nextUndoStack = { ...hepaUndoStack };
    delete nextUndoStack[machine];
    const nextArchives = archives.filter(a => !archiveIdsToRemove.includes(a.id));

    setHepaSettings(nextSettings);
    setEditHepa(nextEditHepa);
    setHepaUndoStack(nextUndoStack);
    setArchives(nextArchives);
    if (archiveIdsToRemove.includes(selectedArchiveId)) setSelectedArchiveId(null);
    lsSet("mau_hepa_settings", nextSettings);
    lsSet("mau_hepa_archives", nextArchives);
    lsSet("mau_hepa_undo_stack", nextUndoStack);
    setDateRange({ start: "", end: "" });
    setRestoreConfirm(null);
  }

  function requestDeleteArchive(archive) {
    setDeleteArchiveConfirm(archive);
  }

  function confirmDeleteArchive() {
    if (!deleteArchiveConfirm) return;
    const archiveId = deleteArchiveConfirm.id;
    const nextArchives = archives.filter(a => a.id !== archiveId);
    const nextUndoStack = Object.fromEntries(
      Object.entries(hepaUndoStack).map(([machine, record]) => {
        if (!record || !Array.isArray(record.archiveIds)) return [machine, record];
        return [machine, { ...record, archiveIds: record.archiveIds.filter(id => id !== archiveId) }];
      })
    );
    setArchives(nextArchives);
    setHepaUndoStack(nextUndoStack);
    if (selectedArchiveId === archiveId) setSelectedArchiveId(null);
    lsSet("mau_hepa_archives", nextArchives);
    lsSet("mau_hepa_undo_stack", nextUndoStack);
    setDeleteArchiveConfirm(null);
  }

  function saveEnergyConfig() {
    const next = Object.fromEntries(Object.entries(editConfig).map(([k, v]) => [k, num(v)]));
    setEnergyConfig(next);
    lsSet("mau_energy_config", next);
  }

  function resetSettings() {
    setHepaSettings(DEFAULT_HEPA_SETTINGS);
    setEditHepa(DEFAULT_HEPA_SETTINGS);
    setEnergyConfig(DEFAULT_ENERGY_CONFIG);
    setEditConfig(DEFAULT_ENERGY_CONFIG);
    setHepaUndoStack({});
    lsSet("mau_hepa_settings", DEFAULT_HEPA_SETTINGS);
    lsSet("mau_energy_config", DEFAULT_ENERGY_CONFIG);
    lsSet("mau_hepa_undo_stack", {});
    setDateRange({ start: "", end: "" });
  }

  return (
    <div className="min-h-screen bg-slate-50 p-5 text-slate-900">
      {deleteArchiveConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
            <h2 className="text-xl font-bold text-slate-900">確認刪除歷史封存資料</h2>
            <p className="mt-3 text-sm text-slate-600">是否確定刪除此筆歷史封存資料？刪除後會從後台資料中整筆移除，無法再次查看。</p>
            <div className="mt-4 rounded-2xl bg-red-50 p-4 text-sm text-red-800">
              <div className="font-semibold">即將刪除的資料</div>
              <div>機台：{deleteArchiveConfirm.machine.replace("MAUC","C")}</div>
              <div>舊清洗日：{deleteArchiveConfirm.fromReplaceDate}</div>
              <div>新清洗日：{deleteArchiveConfirm.toReplaceDate}</div>
              <div>封存筆數：{deleteArchiveConfirm.rowCount?.toLocaleString?.() || "-"}</div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setDeleteArchiveConfirm(null)} className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">取消</button>
              <button onClick={confirmDeleteArchive} className="rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700">確認刪除</button>
            </div>
          </div>
        </div>
      )}

      {restoreConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl">
            <h2 className="text-xl font-bold text-slate-900">確認還原 HEPA 設定</h2>
            <p className="mt-3 text-sm text-slate-600">是否刪除目前儲存設定，並還原成上一筆儲存前的數值？</p>
            <div className="mt-4 rounded-2xl bg-red-50 p-4 text-sm text-red-800">
              <div className="font-semibold">將刪除目前設定</div>
              <div>機台：{restoreConfirm.machine.replace("MAUC","C")}</div>
              <div>清洗時間為 {restoreConfirm.currentSetting?.replaceDate || "-"}</div>
              <div>初始壓差為 {restoreConfirm.currentSetting?.initialPT ?? "-"} Pa</div>
            </div>
            <div className="mt-3 rounded-2xl bg-emerald-50 p-4 text-sm text-emerald-800">
              <div className="font-semibold">還原後設定</div>
              <div>清洗時間為 {restoreConfirm.previousSetting?.replaceDate || "-"}</div>
              <div>初始壓差為 {restoreConfirm.previousSetting?.initialPT ?? "-"} Pa</div>
            </div>
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setRestoreConfirm(null)} className="rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">取消</button>
              <button onClick={confirmRestoreSelectedHepa} className="rounded-xl bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700">確認刪除並還原</button>
            </div>
          </div>
        </div>
      )}

      <div className="mx-auto max-w-[1900px] space-y-5">
        <header className="rounded-3xl bg-gradient-to-r from-slate-900 to-slate-700 p-6 text-white shadow-lg">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <h1 className="text-3xl font-bold tracking-tight">MAU HEPA更換警報系統</h1>
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl bg-white px-4 py-3 font-semibold text-slate-900 shadow-sm hover:bg-slate-100">
              <Upload size={18} /> 匯入 Excel / CSV
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFile} />
            </label>
          </div>
        </header>

        <section className="grid grid-cols-1 gap-3 md:grid-cols-4">
          <StatPill label="目前檔案" value={fileName || "尚未匯入"} />
          <StatPill label="原始資料筆數" value={rawRows.length.toLocaleString()} />
          <StatPill label="HEPA 更換成本" value={`${fmt(replacementCost)} NTD`} />
          <StatPill label="目前選擇機台" value={selectedMachine.replace("MAUC","C")} />
        </section>

        <section className="rounded-3xl border border-slate-700 bg-slate-800 p-4 text-white shadow-sm">
          <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><CheckCircle2 size={18} /> C01–C08 即時摘要</h2>
          <div className="overflow-auto rounded-2xl bg-white text-slate-900">
            <table className="w-full min-w-[980px] text-sm">
              <thead>
                <tr className="border-b bg-slate-100 text-left text-slate-700">
                  <th className="p-2">機台</th><th className="p-2">清洗日</th><th className="p-2">初始 Pa</th><th className="p-2">生命週期資料</th><th className="p-2">最佳點</th><th className="p-2">警示</th><th className="p-2">最新 HEPAPT</th><th className="p-2">每日額外 kWh</th><th className="p-2">觀測累積電費</th>
                </tr>
              </thead>
              <tbody>
                {MACHINES.map(m => {
                  const d = dashboardData[m];
                  const last = d?.daily?.[d.daily.length - 1];
                  return (
                    <tr key={m} className={`border-b hover:bg-slate-50 ${selectedMachine === m ? "bg-blue-50" : ""}`}>
                      <td className="p-2 font-semibold"><button onClick={() => setSelectedMachine(m)}>{m.replace("MAUC","C")}</button></td>
                      <td className="p-2">{hepaSettings[m]?.replaceDate}</td>
                      <td className="p-2">{hepaSettings[m]?.initialPT}</td>
                      <td className="p-2">{d?.hasLifecycleStart ? "Yes" : "Observed only"}</td>
                      <td className="p-2">{d?.alert?.optimumDate || "-"}</td>
                      <td className="p-2"><AlertBadge level={d?.alert?.level} message={d?.alert?.message || "-"} /></td>
                      <td className="p-2">{fmt(last?.hepaMean, 1)}</td>
                      <td className="p-2">{fmt(last?.extraKWh, 2)}</td>
                      <td className="p-2">{fmt(last?.observedCumulativeCost, 0)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        <section className="rounded-3xl border border-slate-700 bg-slate-800 p-4 text-white shadow-sm">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-lg font-bold">MAU 能耗 / 成本參數設定</h2>
            <div className="flex gap-2">
              <button onClick={saveEnergyConfig} className="inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-semibold text-slate-900 hover:bg-slate-100"><Save size={16} /> 儲存並重算</button>
              <button onClick={resetSettings} className="inline-flex items-center gap-2 rounded-xl border border-slate-500 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700"><RefreshCcw size={16} /> 還原預設</button>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
            {[
              ["designCMH","風機設計 CMH"], ["fanEfficiency","送風機效率 η"],
              ["hepaUnitCost","HEPA 單價"], ["hepaQty","HEPA 數量"], ["laborCost","施工/更換費"],
              ["electricityPrice","電費 NTD/kWh"], ["earlyWarningDays","提前通報天數"],
              ["minUseDays","最低使用天數（避免剛更換時年化成本失真）"],
              ["smoothWindow","平滑天數（移動平均降低曲線波動）"],
            ].map(([key,label]) => (
              <div key={key}>
                <label className="block text-xs text-slate-300">{label}</label>
                <input type="number" value={editConfig[key]} onChange={e => setEditConfig({ ...editConfig, [key]: e.target.value })} className="mt-1 w-full rounded-xl border border-slate-500 bg-white px-3 py-2 text-sm text-slate-900" />
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-3 flex items-center gap-2"><SlidersHorizontal size={18} /><h2 className="text-lg font-bold">選擇機台</h2></div>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 xl:grid-cols-8">
            {MACHINES.map(m => (
              <button key={m} onClick={() => setSelectedMachine(m)} className={`rounded-2xl border px-4 py-3 text-left font-semibold ${selectedMachine === m ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200 bg-white hover:bg-slate-50"}`}>
                <div className="text-lg">{m.replace("MAUC","C")}</div><div className="text-xs text-slate-500">{m}</div>
              </button>
            ))}
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4">
          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2"><Settings size={18} /><h2 className="text-lg font-bold">{selectedMachine.replace("MAUC","C")} HEPA 清洗 / 更換設定</h2></div>
              <div className="flex gap-2">
                <button onClick={saveSelectedHepa} className="inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-700"><Save size={16} /> 儲存此機台</button>
                <button onClick={restoreSelectedHepa} className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"><RefreshCcw size={16} /> 還原上一步</button>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <div><label className="block text-xs text-slate-500">清洗 / 更換日期</label><input type="date" value={editHepa[selectedMachine]?.replaceDate || ""} onChange={e => setEditHepa({ ...editHepa, [selectedMachine]: { ...editHepa[selectedMachine], replaceDate: e.target.value } })} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm" /></div>
              <div><label className="block text-xs text-slate-500">HEPA 初始壓差 Pa</label><input type="number" value={editHepa[selectedMachine]?.initialPT ?? ""} onChange={e => setEditHepa({ ...editHepa, [selectedMachine]: { ...editHepa[selectedMachine], initialPT: e.target.value } })} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm" /></div>
            </div>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-3 md:grid-cols-5">
          <StatPill label="資料起始日" value={selected.dataStart || "-"} />
          <StatPill label="資料結束日" value={selected.dataEnd || "-"} />
          <StatPill label="生命週期資料" value={selected.hasLifecycleStart ? "是" : "否"} />
          <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm"><div className="text-xs text-slate-500">目前警示</div><div className="mt-2"><AlertBadge level={selected.alert?.level} message={selected.alert?.message} /></div></div>
          <div className="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm"><div className="text-xs text-slate-500">圖表區間</div><div className="mt-2 text-sm font-semibold">{rangeStart || "-"} ～ {rangeEnd || "-"}</div></div>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="mb-3 text-lg font-bold">圖表顯示時間區間</div>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
            <div><label className="block text-xs text-slate-500">開始日期</label><input type="date" value={rangeStart} onChange={e => setDateRange({ ...dateRange, start: e.target.value })} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm" /></div>
            <div><label className="block text-xs text-slate-500">結束日期</label><input type="date" value={rangeEnd} onChange={e => setDateRange({ ...dateRange, end: e.target.value })} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2 text-sm" /></div>
            <div className="flex items-end"><button onClick={() => setDateRange({ start: "", end: "" })} className="w-full rounded-xl border border-slate-300 px-4 py-2 text-sm font-semibold hover:bg-slate-50">回到預設：清洗日～最新資料日</button></div>
          </div>
        </section>

        <section className="grid grid-cols-1 gap-4">
          <ChartCard title={`${selectedMachine.replace("MAUC","C")}｜每日平均 HEPA 壓差`}>
            <ResponsiveContainer width="100%" height="100%"><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="hepaMean" name="每日平均 HEPAPT" stroke={COLORS.hepa} dot={false} strokeWidth={2} /><Line type="monotone" dataKey="initialPT" name="初始壓差" stroke="#64748b" dot={false} strokeDasharray="4 4" /></LineChart></ResponsiveContainer>
          </ChartCard>

          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm space-y-5">
            <div><h3 className="mb-2 text-base font-semibold">每日額外耗電 kWh</h3><div className="h-[260px]"><ResponsiveContainer width="100%" height="100%"><BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis /><Tooltip /><Legend /><Bar dataKey="extraKWh" name="每日額外耗電 kWh" fill={COLORS.kwh} /></BarChart></ResponsiveContainer></div></div>
            <div><h3 className="mb-2 text-base font-semibold">每日額外耗電成本 NTD</h3><div className="h-[260px]"><ResponsiveContainer width="100%" height="100%"><BarChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis /><Tooltip /><Legend /><Bar dataKey="extraCost" name="每日額外耗電成本 NTD" fill={COLORS.cost} /></BarChart></ResponsiveContainer></div></div>
            <div><h3 className="mb-2 text-base font-semibold">累積額外耗電成本 NTD</h3><div className="h-[280px]"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="lifecycleCumulativeCost" name="生命週期累積額外耗電成本" stroke={COLORS.annualExtra} dot={false} strokeWidth={3} /><Line type="monotone" dataKey="observedCumulativeCost" name="觀測區間累積額外耗電成本" stroke={COLORS.cost} dot={false} strokeWidth={2} strokeDasharray="5 5" /></LineChart></ResponsiveContainer></div></div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm space-y-5">
            <div>
              <h3 className="mb-1 text-base font-semibold text-slate-900">{selectedMachine.replace("MAUC","C")}｜年化總成本曲線</h3>
              <div className="h-[320px]"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis scale="log" domain={[1, "auto"]} allowDataOverflow /><Tooltip /><Legend /><Line type="monotone" dataKey="annualTotalCost_smooth" name="年化總成本" stroke={COLORS.annual} dot={false} strokeWidth={5} connectNulls /></LineChart></ResponsiveContainer></div>
            </div>
            <div>
              <h3 className="mb-1 text-base font-semibold text-slate-900">年化 HEPA 更換成本 vs 年化額外耗電成本</h3>
              <div className="h-[320px]"><ResponsiveContainer width="100%" height="100%"><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis scale="log" domain={[1, "auto"]} allowDataOverflow /><Tooltip /><Legend /><Line type="monotone" dataKey="annualHepaCost" name="年化 HEPA 更換成本" stroke={COLORS.annualHepa} dot={false} strokeWidth={3} connectNulls /><Line type="monotone" dataKey="annualExtraCost" name="年化額外耗電成本" stroke={COLORS.annualExtra} dot={false} strokeWidth={3} connectNulls /></LineChart></ResponsiveContainer></div>
            </div>
          </div>

          <ChartCard title={`${selectedMachine.replace("MAUC","C")}｜MC / AC 驗證`}>
            <ResponsiveContainer width="100%" height="100%"><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" minTickGap={24} /><YAxis scale="log" domain={[0.1, "auto"]} allowDataOverflow /><Tooltip /><Legend /><Line type="monotone" dataKey="mcDay_smooth" name="MC 每日邊際成本" stroke={COLORS.mc} dot={false} strokeWidth={3} connectNulls /><Line type="monotone" dataKey="acDay_smooth" name="AC 每日平均成本" stroke={COLORS.ac} dot={false} strokeWidth={3} connectNulls /><ReferenceLine x={selected.mcAcOptimum?.date} stroke="#f97316" strokeDasharray="5 5" label="MC=AC" /></LineChart></ResponsiveContainer>
          </ChartCard>
        </section>

        <section className="grid grid-cols-1 gap-4 xl:grid-cols-2">
          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><Bell size={18} /> {selectedMachine.replace("MAUC","C")} 警示通報</h2>
            <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
              <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs text-slate-500">目前狀態</div><div className="mt-2"><AlertBadge level={selected.alert?.level} message={selected.alert?.message} /></div></div>
              <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs text-slate-500">最佳點</div><div className="mt-2 text-xl font-bold">{selected.alert?.optimumDate || "尚無"}</div></div>
              <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs text-slate-500">黃色通報起始</div><div className="mt-2 text-xl font-bold">{selected.alert?.yellowDate || "尚無"}</div></div>
              <div className="rounded-2xl bg-slate-50 p-4"><div className="text-xs text-slate-500">距離最佳點</div><div className="mt-2 text-xl font-bold">{selected.alert?.daysToOptimum ?? "-"} 天</div></div>
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><Archive size={18} /> {selectedMachine.replace("MAUC","C")} 歷史封存區段</h2>
            {selectedArchives.length === 0 ? (
              <p className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-500">此機台尚無封存資料。</p>
            ) : (
              <div className="space-y-4">
                <div className="max-h-[220px] overflow-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="border-b bg-slate-100 text-left text-slate-700"><th className="p-2">舊清洗日</th><th className="p-2">新清洗日</th><th className="p-2">封存筆數</th><th className="p-2">封存時間</th><th className="p-2">刪除</th></tr></thead>
                    <tbody>
                      {selectedArchives.slice().reverse().map(a => (
                        <tr key={a.id} onClick={() => setSelectedArchiveId(a.id)} className={`cursor-pointer border-b hover:bg-blue-50 ${selectedArchiveId === a.id ? "bg-blue-50" : ""}`}>
                          <td className="p-2 font-semibold text-blue-700">{a.fromReplaceDate}</td>
                          <td className="p-2 font-semibold text-blue-700">{a.toReplaceDate}</td>
                          <td className="p-2">{a.rowCount?.toLocaleString?.()}</td>
                          <td className="p-2">{new Date(a.archivedAt).toLocaleString()}</td>
                          <td className="p-2">
                            <button onClick={(e) => { e.stopPropagation(); requestDeleteArchive(a); }} className="inline-flex items-center justify-center rounded-lg border border-red-200 bg-red-50 p-2 text-red-600 hover:bg-red-100" title="刪除此筆歷史封存資料">
                              <Trash2 size={16} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {selectedArchive ? (
                  <div className="rounded-2xl border border-slate-200 p-3">
                    <h3 className="mb-2 text-sm font-bold text-slate-800">封存區間圖：{selectedArchive.fromReplaceDate} ～ {selectedArchive.toReplaceDate}</h3>
                    <div className="h-[260px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={selectedArchiveChartData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" minTickGap={20} />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <ReferenceLine x={selectedArchive.fromReplaceDate} stroke="#64748b" strokeDasharray="4 4" label="舊清洗日" />
                          <ReferenceLine x={selectedArchive.toReplaceDate} stroke="#f97316" strokeDasharray="4 4" label="新清洗日" />
                          <Line type="monotone" dataKey="hepaMean" name="每日平均 HEPAPT" stroke={COLORS.hepa} dot={false} strokeWidth={2} connectNulls />
                          <Line type="monotone" dataKey="initialPT" name="初始壓差" stroke="#64748b" dot={false} strokeDasharray="5 5" connectNulls />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                ) : (
                  <p className="rounded-2xl bg-slate-50 p-3 text-sm text-slate-500">點選上方任一封存區段，即可顯示該舊清洗日到新清洗日之間的 HEPA 壓差圖。</p>
                )}
              </div>
            )}
          </div>
        </section>

        <section className="rounded-3xl border border-orange-200 bg-orange-50 p-5 shadow-sm">
          <h2 className="mb-4 text-xl font-bold text-orange-900">系統核心公式</h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <div className="rounded-2xl border border-orange-200 bg-white p-4 shadow-sm">
              <div className="mb-3 text-base font-bold text-orange-800">1. HEPA 耗電量公式</div>
              <div className="rounded-2xl bg-orange-50 p-4 text-center text-slate-900">
                <div className="mt-1 inline-flex items-center justify-center gap-3 text-xl font-bold">
                  <span className="text-orange-700">W =</span>
                  <div className="inline-flex flex-col items-center">
                    <div className="border-b border-slate-500 px-4 pb-2">Q × ΔP × t</div>
                    <div className="pt-2">η × 1000</div>
                  </div>
                </div>
              </div>
              <div className="mt-3 rounded-2xl bg-orange-50 p-3 text-center text-xs font-medium text-slate-700">
                Q = 單台MAU風量設計CMH × FREQ / 60 / 3600
              </div>
            </div>

            <div className="rounded-2xl border border-orange-200 bg-white p-4 shadow-sm">
              <div className="mb-3 text-base font-bold text-orange-800">2. 年化 HEPA 總成本公式</div>
              <div className="rounded-2xl bg-orange-50 p-4 text-center text-slate-900">
                <div className="mt-1 inline-flex flex-wrap items-center justify-center gap-2 text-sm font-bold md:flex-nowrap">
                  <span className="shrink-0 text-orange-700">年化總成本 =</span>
                  <div className="inline-flex flex-col items-center">
                    <div className="whitespace-nowrap border-b border-slate-500 px-2 pb-1 leading-6">HEPA 更換成本 + 額外耗電成本</div>
                    <div className="pt-1">使用時間</div>
                  </div>
                  <div className="shrink-0 text-lg font-bold text-slate-900">× 365</div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-orange-200 bg-white p-4 shadow-sm">
              <div className="mb-3 text-base font-bold text-orange-800">3. MC / AC 驗證邏輯</div>
              <div className="rounded-2xl bg-orange-50 p-4 text-center text-slate-900">
                <div className="text-2xl font-bold text-orange-700">MC ≈ AC</div>
              </div>
              <div className="mt-3 space-y-2 rounded-2xl bg-orange-50 p-4 text-sm leading-7 text-slate-700">
                <div><span className="font-bold text-orange-800">MC：</span>每日邊際成本（Marginal Cost）</div>
                <div><span className="font-bold text-orange-800">AC：</span>每日平均成本（Average Cost）</div>
                <div className="border-t border-orange-200 pt-3 font-semibold text-slate-900">當 MC ≈ AC 時，理論上接近成本最佳化點</div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
